const sentences = [
  "A QUICK BROWN FOX JUMPS OVER THE LAZY DOG",
  "HEAVY BOXES PERFORM QUICK WALTZES AND JIGS",
  "SYMPATHIZING WOULD FIX QUAKER OBJECTIVES",
  "QUICK FOX JUMPS NIGHTLY ABOVE WIZARD",
  "TWO DRIVEN JOCKS HELP FAX MY BIG QUIZ",
  "FICKLE JINX BOG DWARVES SPY MATH QUIZ"
];

const morseCode = {
   "A": ".-",
   "B": "-...",
   "C": "-.-.",
   "D": "-..",
   "E": ".",
   "F": "..-.",
   "G": "--.",
   "H": "....",
   "I": "..",
   "J": ".---",
   "K": "-.-",
   "L": ".-..",
   "M": "--",
   "N": "-.",
   "O": "---",
   "P": ".--.",
   "Q": "--.-",
   "R": ".-.",
   "S": "...",
   "T": "-",
   "U": "..-",
   "V": "...-",
   "W": ".--",
   "X": "-..-",
   "Y": "-.--",
   "Z": "--.."
};

let tempSentence = "";
let tempMorse = [];
let keyBuffer = "";

const generateUI = (id) => {
  const main = document.getElementById('main');
  main.innerHTML = '';
  const table = document.createElement('table');

  // header
  const hRow = document.createElement('tr');
  const hCell = document.createElement('th');
  hCell.setAttribute('colspan', `${tempSentence.length}`);
  hCell.innerHTML = `KEY #${id}`;
  hRow.appendChild(hCell);
  table.appendChild(hRow);

  // Sentence
  const sRow = document.createElement("tr");
  const sArray = tempSentence.split("");
  for (let i = 0; i < sArray.length; i += 1) {
    const cell = document.createElement('td');
    cell.innerHTML = (sArray[i] === ' ') ? '&nbsp;' : sArray[i];
    sRow.appendChild(cell);
  }
  table.appendChild(sRow);

  // Morse
  const mRow = document.createElement("tr");
  for (let i = 0; i < tempMorse.length; i += 1) {
    const cell = document.createElement('td');
    cell.innerHTML = (tempMorse[i] === ' ') ? '&nbsp;' : tempMorse[i];
    mRow.appendChild(cell);
  }
  table.appendChild(mRow);

  // Key
  const kRow = document.createElement("tr");
  const kArray = keyBuffer.split("");
  const found = false;
  for (let i = 0; i < tempMorse.length; i += 1) {
    const cell = document.createElement('td');
    cell.innerHTML = ((keyBuffer[i] === ' ') ? '&nbsp;' : keyBuffer[i]) || '&nbsp;';
    if (i === 0 && keyBuffer.length === 0) {
      cell.className = 'highlighted';
    }
    if (i > 0 && i === keyBuffer.length && sArray[i] !== ' ') {
      console.log('sArray[i]:', sArray[i]);
      console.log('keyBuffer[i]:', keyBuffer[i]);
      console.log('keyBuffer length:', keyBuffer.length);
      console.log('i:', i);
      cell.className = 'highlighted';
    } else {
      console.log('keyBuffer length:', keyBuffer.length);
    }
    if (keyBuffer.length > 0) {
      if (keyBuffer[i] !== sArray[i] && keyBuffer[i] !== undefined) {
        cell.innerHTML = '';
        const iFont = document.createElement('font');
        iFont.setAttribute('color','red');
        iFont.innerHTML = keyBuffer[i];
        cell.appendChild(iFont);
      }
    }
    kRow.appendChild(cell);
  }
  table.appendChild(kRow);
  main.appendChild(table);

  if (keyBuffer.length === tempSentence.length) {
    initUI();
  }
}

const initUI = () => {
  tempSentence = '';
  tempMorse = [];
  keyBuffer = '';
  const num = Math.floor(Math.random() * ((sentences.length - 1) + 1));
  tempSentence = sentences[num];
  const tArray = tempSentence.split("");
  for (let i = 0; i < tArray.length; i += 1) {
    const tChar = tArray[i];
    if (tChar !== " ") {
      tempMorse.push(morseCode[tChar]);
    } else {
      tempMorse.push(" ");
    }
  }
  console.info('Sentence: ', tempSentence);
  console.info('Morse: ', tempMorse);
  generateUI(1);
};


const updateLetter = (letter) => {
  const kArray = keyBuffer.split("");
  const sArray = tempSentence.split("");
  const len = kArray.length;
  keyBuffer += letter;
  if (sArray[len + 1] === ' ') {
    keyBuffer += " ";
  }
  generateUI(1);
};

const parseMessage = (msg) => {
  // MSG:1~O
  const sA = msg.split(":");
  if (sA.length === 2) {
    if (sA[0] === "MSG") {
      const sB = sA[1].split("~");
      if (sB.length === 2) {
        const id = sB[0];
        const letter = sB[1];
        updateLetter(letter);
      }
    }
  }
};

initUI();
