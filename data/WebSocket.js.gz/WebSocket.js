const connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);

connection.onopen = function () {
    connection.send('Connect ' + new Date());
};
connection.onerror = function (error) {
    console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {
    receivedMessage(e.data);
};
connection.onclose = function(){
    console.log('WebSocket connection closed');
};

const receivedMessage = (msg) => {
  console.log(`Received Message: ${msg}`);
  parseMessage(msg);
  // var txtDemo1 = document.getElementById('txtDemo1');
  // txtDemo1.value += `${msg}\n`;
  // txtDemo1.scrollTop = txtDemo1.scrollHeight
  // connection.send('SOME MESSAGE');
}

const sendMessage = (msg) => {
  connection.send(msg);
  console.log(`Sent Message: ${msg}`);
}
